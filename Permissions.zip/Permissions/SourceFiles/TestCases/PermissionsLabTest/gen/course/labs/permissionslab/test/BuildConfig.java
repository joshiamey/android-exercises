/** Automatically generated file. DO NOT MODIFY */
package course.labs.permissionslab.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}